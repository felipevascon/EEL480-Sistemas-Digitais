library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

------------------------
-- Entity Declaration --
------------------------
entity stateMachine is
    port(
        dataIn: in std_logic_vector(3 downto 0);       -- 4-bit input (can be operation code, number 1, or number 2)
        setBtn: in std_logic;                          -- Button to advance between states
        resetBtn: in std_logic;                        -- Button to reset to the initial state
        clock: in std_logic;                           -- Main clock of the system
        resultLeds: out std_logic_vector(3 downto 0);  -- LEDs showing the operation result
        flagLeds: out std_logic_vector(3 downto 0)     -- LEDs showing ALU flags
    );
end stateMachine;

architecture hardware of stateMachine is

    -------------------------------------------------
    -- ALU component to be instantiated in the project
    -------------------------------------------------
    component alu is
        port(
            sel: in std_logic_vector(3 downto 0);         -- Operation code to be performed
            xnum: in std_logic_vector(3 downto 0);        -- First operand
            ynum: in std_logic_vector(3 downto 0);        -- Second operand
            cout: out std_logic;                          -- Carry out flag
            zeroFlag: out std_logic;                      -- Zero flag
            signFlag: out std_logic;                      -- Sign flag
            ovFlag: out std_logic;                        -- Overflow flag
            result: out std_logic_vector(3 downto 0)      -- Operation result
        );
    end component;

    -- Internal signals to synchronize and debounce the buttons
    signal setBtnSync1, setBtnSync2: std_logic := '0';
    signal resetBtnSync1, resetBtnSync2: std_logic := '0';
    signal debouncedSet, debouncedReset: std_logic := '0';

    signal setBtnPrev, resetBtnPrev: std_logic := '0';

    -- Internal signals to store input data
    signal numOp, num1, num2: std_logic_vector(3 downto 0);

    -- Internal signals to capture ALU flags
    signal fsmCout: std_logic := '0';
    signal fsmZeroFlag: std_logic := '0';
    signal fsmSignFlag: std_logic := '0';
    signal fsmOvFlag: std_logic := '0';

    -- ALU result
    signal outputAlu: std_logic_vector(3 downto 0) := "0000";

    -- Define state type and control signal for FSM
    type stateType is (s0, s1, s2, s3);  -- s0: operation, s1: num1, s2: num2, s3: result
    signal currentState, nextState: stateType := s0;

begin

    -- ALU instantiation connecting internal signals
    aluLabel: alu port map(
        sel => numOp,
        xnum => num1,
        ynum => num2,
        cout => fsmCout,
        zeroFlag => fsmZeroFlag,
        signFlag => fsmSignFlag,
        ovFlag => fsmOvFlag,
        result => outputAlu
    );

    --------------------------------------
    -- Set button debounce process --
    --------------------------------------
    process(clock)
    begin
        if rising_edge(clock) then
            setBtnSync1 <= setBtn;
            setBtnSync2 <= setBtnSync1;

            -- Generate a 1-clock pulse when the button is pressed
            if (setBtnSync2 = '1' and setBtnPrev = '0') then
                debouncedSet <= '1';
            else
                debouncedSet <= '0';
            end if;

            setBtnPrev <= setBtnSync2;
        end if;
    end process;

    ----------------------------------------
    -- Reset button debounce process --
    ----------------------------------------
    process(clock)
    begin
        if rising_edge(clock) then
            resetBtnSync1 <= resetBtn;
            resetBtnSync2 <= resetBtnSync1;

            -- Generate a 1-clock pulse when the button is pressed
            if (resetBtnSync2 = '1' and resetBtnPrev = '0') then
                debouncedReset <= '1';
            else
                debouncedReset <= '0';
            end if;

            resetBtnPrev <= resetBtnSync2;
        end if;
    end process;

    ---------------------------------------------------
    -- FSM state transition process --
    ---------------------------------------------------
    process(clock)
    begin
        if rising_edge(clock) then
            if debouncedReset = '1' then
                currentState <= s0;  -- Always return to the initial state if reset is pressed
            else
                currentState <= nextState;
            end if;
        end if;
    end process;

    ------------------------------------------------------
    -- Next state transition logic (combinational) --
    ------------------------------------------------------
    process(currentState, debouncedSet, debouncedReset)
    begin
        nextState <= currentState; -- default value

        case currentState is
            when s0 =>
                if debouncedSet = '1' then
                    nextState <= s1;
                end if;
            when s1 =>
                if debouncedSet = '1' then
                    nextState <= s2;
                end if;
            when s2 =>
                if debouncedSet = '1' then
                    nextState <= s3;
                end if;
            when s3 =>
                -- In state s3, only reset can exit the state
                null;
        end case;
    end process;

    -------------------------------------------------------
    -- Capture input values according to the state --
    -------------------------------------------------------
    process(clock)
    begin
        if rising_edge(clock) then
            case currentState is
                when s0 =>
                    if debouncedSet = '1' then
                        numOp <= dataIn;  -- Capture the operation code
                    end if;
                when s1 =>
                    if debouncedSet = '1' then
                        num1 <= dataIn;   -- Capture the first number
                    end if;
                when s2 =>
                    if debouncedSet = '1' then
                        num2 <= dataIn;   -- Capture the second number
                    end if;
                when s3 =>
                    null; -- Nothing is captured, just display result
            end case;
        end if;
    end process;

    -----------------------------------------------------------------
    -- Control LED outputs based on current FSM state --
    -----------------------------------------------------------------
    process (currentState, numOp, num1, num2, outputAlu, fsmCout, fsmZeroFlag, fsmSignFlag, fsmOvFlag)
    begin
        case currentState is
            when s0 =>
                resultLeds <= "0001";   -- Visual indication of state s0
                flagLeds <= "0000";
            when s1 =>
                resultLeds <= "0010";   -- Visual indication of state s1
                flagLeds <= "0000";
            when s2 =>
                resultLeds <= "0011";   -- Visual indication of state s2
                flagLeds <= "0000";
            when s3 =>
                resultLeds <= outputAlu;   -- Display ALU result
                flagLeds(0) <= fsmCout;    -- Display ALU flags
                flagLeds(1) <= fsmZeroFlag;
                flagLeds(2) <= fsmSignFlag;
                flagLeds(3) <= fsmOvFlag;
        end case;
    end process;

end hardware;

LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
ENTITY stateMachineTb IS
END stateMachineTb;
 
ARCHITECTURE behavior OF stateMachineTb IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT stateMachine
    PORT(
         dataIn : IN  std_logic_vector(3 downto 0);
         setBtn : IN  std_logic;
         resetBtn : IN  std_logic;
         clock : IN  std_logic;
         resultLeds : OUT  std_logic_vector(3 downto 0);
         flagLeds : OUT  std_logic_vector(3 downto 0)
        );
    END COMPONENT;
    

   --Inputs
   signal dataIn : std_logic_vector(3 downto 0) := (others => '0');
   signal setBtn : std_logic := '0';

   signal resetBtn : std_logic := '0';
   signal clock : std_logic := '0';

 	--Outputs
   signal resultLeds : std_logic_vector(3 downto 0);
   signal flagLeds : std_logic_vector(3 downto 0);

   -- Clock period definitions
   constant clock_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: stateMachine PORT MAP (
          dataIn => dataIn,
          setBtn => setBtn,

          resetBtn => resetBtn,
          clock => clock,
          resultLeds => resultLeds,
          flagLeds => flagLeds
        );

   -- Clock process definitions
   clock_process :process
   begin
		clock <= '0';
		wait for clock_period/2;
		clock <= '1';
		wait for clock_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
      wait for 100 ns;	

      wait for clock_period*10;

      -- insert stimulus here 
		
		resetBtn <= '1';
		wait for 100 ns;
		resetBtn <= '0';
		wait for 100 ns;
		
		dataIn <= "0101";
		setBtn <= '1';
		wait for 20 ns;
		setBtn <= '0';
		wait for 20 ns;
		
		dataIn <= "0010";
		setBtn <= '1';
		wait for 20 ns;
		setBtn <= '0';
		wait for 20 ns;
		
		dataIn <= "0001";
		setBtn <= '1';
		wait for 20 ns;
		setBtn <= '0';
		
		resetBtn <= '1';
		wait for 100 ns;
		resetBtn <= '0';
		wait for 100 ns;
		
      wait;
   end process;

END;

/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/media/SANDISK/trabsistdigit/comparator.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_3488546069778340532_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_3488768496604610246_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_3496108612141461530_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_374109322130769762_503743352(char *, unsigned char );


static void work_a_2683404259_1214131516_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    char *t23;
    char *t24;
    int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned char t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned char t38;
    char *t39;
    char *t40;
    int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned char t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned char t54;
    char *t55;
    char *t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned char t61;
    unsigned char t62;
    unsigned char t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;

LAB0:    xsi_set_current_line(18, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (3 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t10 = (3 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_3496108612141461530_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1032U);
    t17 = *((char **)t16);
    t18 = (2 - 3);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = (t0 + 1192U);
    t24 = *((char **)t23);
    t25 = (2 - 3);
    t26 = (t25 * -1);
    t27 = (1U * t26);
    t28 = (0 + t27);
    t23 = (t24 + t28);
    t29 = *((unsigned char *)t23);
    t30 = ieee_p_2592010699_sub_3496108612141461530_503743352(IEEE_P_2592010699, t22, t29);
    t31 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t15, t30);
    t32 = (t0 + 1032U);
    t33 = *((char **)t32);
    t34 = (1 - 3);
    t35 = (t34 * -1);
    t36 = (1U * t35);
    t37 = (0 + t36);
    t32 = (t33 + t37);
    t38 = *((unsigned char *)t32);
    t39 = (t0 + 1192U);
    t40 = *((char **)t39);
    t41 = (1 - 3);
    t42 = (t41 * -1);
    t43 = (1U * t42);
    t44 = (0 + t43);
    t39 = (t40 + t44);
    t45 = *((unsigned char *)t39);
    t46 = ieee_p_2592010699_sub_3496108612141461530_503743352(IEEE_P_2592010699, t38, t45);
    t47 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t31, t46);
    t48 = (t0 + 1032U);
    t49 = *((char **)t48);
    t50 = (0 - 3);
    t51 = (t50 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t48 = (t49 + t53);
    t54 = *((unsigned char *)t48);
    t55 = (t0 + 1192U);
    t56 = *((char **)t55);
    t57 = (0 - 3);
    t58 = (t57 * -1);
    t59 = (1U * t58);
    t60 = (0 + t59);
    t55 = (t56 + t60);
    t61 = *((unsigned char *)t55);
    t62 = ieee_p_2592010699_sub_3496108612141461530_503743352(IEEE_P_2592010699, t54, t61);
    t63 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t47, t62);
    t64 = (t0 + 4176);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    *((unsigned char *)t68) = t63;
    xsi_driver_first_trans_fast(t64);

LAB2:    t69 = (t0 + 4048);
    *((int *)t69) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2683404259_1214131516_p_1(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    char *t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned char t40;
    char *t41;
    char *t42;
    int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned char t47;
    unsigned char t48;
    unsigned char t49;
    unsigned char t50;
    char *t51;
    char *t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned char t57;
    char *t58;
    char *t59;
    int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned char t64;
    unsigned char t65;
    unsigned char t66;
    unsigned char t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;

LAB0:    xsi_set_current_line(19, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (3 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t10 = (3 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t14);
    t16 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t7, t15);
    t17 = (t0 + 1032U);
    t18 = *((char **)t17);
    t19 = (2 - 3);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t17 = (t18 + t22);
    t23 = *((unsigned char *)t17);
    t24 = (t0 + 1192U);
    t25 = *((char **)t24);
    t26 = (2 - 3);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t30);
    t32 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t23, t31);
    t33 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t16, t32);
    t34 = (t0 + 1032U);
    t35 = *((char **)t34);
    t36 = (1 - 3);
    t37 = (t36 * -1);
    t38 = (1U * t37);
    t39 = (0 + t38);
    t34 = (t35 + t39);
    t40 = *((unsigned char *)t34);
    t41 = (t0 + 1192U);
    t42 = *((char **)t41);
    t43 = (1 - 3);
    t44 = (t43 * -1);
    t45 = (1U * t44);
    t46 = (0 + t45);
    t41 = (t42 + t46);
    t47 = *((unsigned char *)t41);
    t48 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t47);
    t49 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t40, t48);
    t50 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t33, t49);
    t51 = (t0 + 1032U);
    t52 = *((char **)t51);
    t53 = (0 - 3);
    t54 = (t53 * -1);
    t55 = (1U * t54);
    t56 = (0 + t55);
    t51 = (t52 + t56);
    t57 = *((unsigned char *)t51);
    t58 = (t0 + 1192U);
    t59 = *((char **)t58);
    t60 = (0 - 3);
    t61 = (t60 * -1);
    t62 = (1U * t61);
    t63 = (0 + t62);
    t58 = (t59 + t63);
    t64 = *((unsigned char *)t58);
    t65 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t64);
    t66 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t57, t65);
    t67 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t50, t66);
    t68 = (t0 + 4240);
    t69 = (t68 + 56U);
    t70 = *((char **)t69);
    t71 = (t70 + 56U);
    t72 = *((char **)t71);
    *((unsigned char *)t72) = t67;
    xsi_driver_first_trans_fast(t68);

LAB2:    t73 = (t0 + 4064);
    *((int *)t73) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2683404259_1214131516_p_2(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned char t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    char *t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned char t40;
    unsigned char t41;
    char *t42;
    char *t43;
    int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned char t48;
    unsigned char t49;
    unsigned char t50;
    char *t51;
    char *t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned char t57;
    unsigned char t58;
    char *t59;
    char *t60;
    int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned char t65;
    unsigned char t66;
    unsigned char t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;

LAB0:    xsi_set_current_line(20, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (3 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t7);
    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t11 = (3 - 3);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t9 = (t10 + t14);
    t15 = *((unsigned char *)t9);
    t16 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t8, t15);
    t17 = (t0 + 1032U);
    t18 = *((char **)t17);
    t19 = (2 - 3);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t17 = (t18 + t22);
    t23 = *((unsigned char *)t17);
    t24 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t23);
    t25 = (t0 + 1192U);
    t26 = *((char **)t25);
    t27 = (2 - 3);
    t28 = (t27 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t25 = (t26 + t30);
    t31 = *((unsigned char *)t25);
    t32 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t24, t31);
    t33 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t16, t32);
    t34 = (t0 + 1032U);
    t35 = *((char **)t34);
    t36 = (1 - 3);
    t37 = (t36 * -1);
    t38 = (1U * t37);
    t39 = (0 + t38);
    t34 = (t35 + t39);
    t40 = *((unsigned char *)t34);
    t41 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t40);
    t42 = (t0 + 1192U);
    t43 = *((char **)t42);
    t44 = (1 - 3);
    t45 = (t44 * -1);
    t46 = (1U * t45);
    t47 = (0 + t46);
    t42 = (t43 + t47);
    t48 = *((unsigned char *)t42);
    t49 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t41, t48);
    t50 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t33, t49);
    t51 = (t0 + 1032U);
    t52 = *((char **)t51);
    t53 = (0 - 3);
    t54 = (t53 * -1);
    t55 = (1U * t54);
    t56 = (0 + t55);
    t51 = (t52 + t56);
    t57 = *((unsigned char *)t51);
    t58 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t57);
    t59 = (t0 + 1192U);
    t60 = *((char **)t59);
    t61 = (0 - 3);
    t62 = (t61 * -1);
    t63 = (1U * t62);
    t64 = (0 + t63);
    t59 = (t60 + t64);
    t65 = *((unsigned char *)t59);
    t66 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t58, t65);
    t67 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t50, t66);
    t68 = (t0 + 4304);
    t69 = (t68 + 56U);
    t70 = *((char **)t69);
    t71 = (t70 + 56U);
    t72 = *((char **)t71);
    *((unsigned char *)t72) = t67;
    xsi_driver_first_trans_fast(t68);

LAB2:    t73 = (t0 + 4080);
    *((int *)t73) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2683404259_1214131516_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(24, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB5;

LAB6:    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB7;

LAB8:
LAB3:    t1 = (t0 + 4096);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(25, ng0);
    t1 = (t0 + 6267);
    t6 = (t0 + 4368);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

LAB5:    xsi_set_current_line(27, ng0);
    t1 = (t0 + 6271);
    t6 = (t0 + 4368);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

LAB7:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 6275);
    t6 = (t0 + 4368);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

}


extern void work_a_2683404259_1214131516_init()
{
	static char *pe[] = {(void *)work_a_2683404259_1214131516_p_0,(void *)work_a_2683404259_1214131516_p_1,(void *)work_a_2683404259_1214131516_p_2,(void *)work_a_2683404259_1214131516_p_3};
	xsi_register_didat("work_a_2683404259_1214131516", "isim/stateMachine_isim_beh.exe.sim/work/a_2683404259_1214131516.didat");
	xsi_register_executes(pe);
}

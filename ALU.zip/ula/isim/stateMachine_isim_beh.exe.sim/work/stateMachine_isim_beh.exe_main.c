/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *STD_STANDARD;
char *IEEE_P_2592010699;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    work_a_4038272074_1214131516_init();
    work_a_1130988942_1214131516_init();
    work_a_3405309905_1214131516_init();
    work_a_0495498285_3212880686_init();
    work_a_1263416347_1214131516_init();
    work_a_3616895101_1214131516_init();
    work_a_1426142008_1214131516_init();
    work_a_1464647036_1214131516_init();
    work_a_2683404259_1214131516_init();
    work_a_0832606739_1214131516_init();
    work_a_2603445318_1214131516_init();


    xsi_register_tops("work_a_2603445318_1214131516");

    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);

    return xsi_run_simulation(argc, argv);

}

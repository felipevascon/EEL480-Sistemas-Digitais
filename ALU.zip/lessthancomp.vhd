library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- 'lessthancomp' entity compares two 4-bit numbers and generates a result
-- based on bitwise logical operations between the input numbers.
entity lessthancomp is
    port(
        xnum: in std_logic_vector(3 downto 0); -- 4-bit input number x
        ynum: in std_logic_vector(3 downto 0); -- 4-bit input number y
        result: out std_logic_vector(3 downto 0) -- Result of the 4-bit logical operation
    );
end lessthancomp;

architecture hardware of lessthancomp is
begin

    -- Assigns the result of the bitwise comparison between xnum and ynum
    -- For each bit, it inverts the corresponding bit of xnum and performs an AND operation with ynum.
    -- This generates a specific result based on the conditions of the bits.

    result(0) <= ((NOT xnum(0)) AND ynum(0)) OR ((NOT xnum(1)) AND ynum(1)) OR ((NOT xnum(2)) AND ynum(2)) OR ((NOT xnum(3)) AND ynum(3));
    result(1) <= '0';
    result(2) <= '0';
    result(3) <= '0';
    
end hardware;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declaration of the equalcomp entity
entity equalcomp is
    port(
        xnum: in std_logic_vector(3 downto 0); -- 4-bit input (xnum)
        ynum: in std_logic_vector(3 downto 0); -- 4-bit input (ynum)
        result: out std_logic_vector(3 downto 0) -- 4-bit result indicating if xnum is equal to ynum
    );
end equalcomp;

-- Architecture that describes the equality comparator functionality
architecture hardware of equalcomp is
begin

    -- Bitwise comparison between xnum and ynum using the XNOR operator
    -- The XNOR returns '1' when the compared bits are equal and '0' when they are different.
    
    result(0) <= (xnum(0) XNOR ynum(0)) AND (xnum(1) XNOR ynum(1)) AND (xnum(2) XNOR ynum(2)) AND (xnum(3) XNOR ynum(3));
    result(1) <= '0';
    result(2) <= '0';
    result(3) <= '0';
    
end hardware;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declaration of the 'andGate' entity
-- This entity performs a bitwise AND operation between two 4-bit vectors
-- and generates two flags (zeroFlag and signFlag) and a result.
entity andGate is
    port(
        xnum: in std_logic_vector(3 downto 0);      -- First 4-bit operand
        ynum: in std_logic_vector(3 downto 0);      -- Second 4-bit operand
        zeroFlag: out std_logic;                    -- Flag indicating if the result is zero
        signFlag: out std_logic;                    -- Flag indicating if the most significant bit is 1 (negative sign)
        result: out std_logic_vector(3 downto 0)    -- Result of the bitwise AND operation
    );
end andGate;

-- Architecture of the entity
architecture hardware of andGate is

    -- Internal signal that stores the result of the AND operation
    signal intResult: std_logic_vector(3 downto 0);

begin

    -- Bitwise AND operation between xnum and ynum
    intResult <= xnum AND ynum;

    -- Generation of the zeroFlag:
    -- If all bits of intResult are 0, then the result is zero => zeroFlag = '1'
    zeroFlag <= NOT(intResult(0) OR intResult(1) OR intResult(2) OR intResult(3));

    -- Generation of the signFlag:
    -- The most significant bit (bit 3) indicates the sign (in two's complement notation)
    signFlag <= intResult(3);

    -- Assigning the final result to the output
    result <= intResult;

end hardware;

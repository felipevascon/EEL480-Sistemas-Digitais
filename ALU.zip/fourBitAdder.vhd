library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declaration of the 'fourBitAdder' entity
-- This component performs the addition of two 4-bit numbers, with support for carry in and carry out,
-- and also calculates the flags: zero, sign, and overflow.
entity fourBitAdder is
    port(
        xnum: in std_logic_vector(3 downto 0);  -- First 4-bit number
        ynum: in std_logic_vector(3 downto 0);  -- Second 4-bit number
        cin: in std_logic;                      -- Carry in (input carry)
        cout: out std_logic;                    -- Carry out (output carry)
        zeroFlag: out std_logic;                -- Flag indicating if the result is zero
        signFlag: out std_logic;                -- Flag indicating the sign (most significant bit)
        ovFlag: out std_logic;                  -- Overflow flag (indicates overflow)
        result: out std_logic_vector(3 downto 0) -- Sum result
    );
end fourBitAdder;

architecture hardware of fourBitAdder is

    -- Declaration of the fullAdder component, used to add each bit individually
    component fullAdder is
        port(
            xnum: in std_logic;     -- Bit from the first number
            ynum: in std_logic;     -- Bit from the second number
            cin: in std_logic;      -- Carry in for the current bit
            cout: out std_logic;    -- Carry out for the current bit
            result: out std_logic   -- Sum result for the current bit
        );
    end component;
    
    -- Signal to store intermediate carry values between adders
    signal carries: std_logic_vector(3 downto 0);

    -- Signal to store the individual results of each adder
    signal FA: std_logic_vector(3 downto 0);

begin

    -- Instantiation of the 4 individual 1-bit adders connected in series (ripple carry)
    
    -- Sum of the least significant bit (bit 0)
    FA_0: fullAdder port map(xnum(0), ynum(0), cin, carries(0), FA(0));
    
    -- Sum of bit 1 with carry coming from bit 0
    FA_1: fullAdder port map(xnum(1), ynum(1), carries(0), carries(1), FA(1));
    
    -- Sum of bit 2 with carry coming from bit 1
    FA_2: fullAdder port map(xnum(2), ynum(2), carries(1), carries(2), FA(2));
    
    -- Sum of the most significant bit (bit 3) with carry coming from bit 2
    FA_3: fullAdder port map(xnum(3), ynum(3), carries(2), carries(3), FA(3));

    -- Calculation of the flags
    
    -- zeroFlag will be '1' if all bits of the result are '0' (i.e., result is zero)
    zeroFlag <= NOT (FA(0) OR FA(1) OR FA(2) OR FA(3));
    
    -- signFlag takes the most significant bit of the result (bit 3)
    -- Useful for representing the sign in two's complement
    signFlag <= FA(3);
    
    -- ovFlag (overflow flag) indicates if there was a sign overflow in the operation
    -- Calculated by the difference between the last two carries
    ovFlag <= carries(2) XOR carries(3);
    
    -- Total carry out of the operation (last carry generated)
    cout <= carries(3);

    -- Final result of the sum
    result <= FA;

end hardware;

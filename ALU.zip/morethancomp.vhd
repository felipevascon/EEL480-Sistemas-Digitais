library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- 'morethancomp' entity compares two 4-bit numbers and generates a result
-- based on bitwise logical operations, indicating if xnum is greater than ynum.
entity morethancomp is
    port(
        xnum: in std_logic_vector(3 downto 0); -- 4-bit input number x
        ynum: in std_logic_vector(3 downto 0); -- 4-bit input number y
        result: out std_logic_vector(3 downto 0) -- Result of the 4-bit logical operation
    );
end morethancomp;

architecture hardware of morethancomp is
begin

    -- Assigns the result of the bitwise comparison between xnum and ynum
    -- For each bit, it checks if the corresponding bit of xnum is 1 and the corresponding bit of ynum is 0.
    -- This generates a result based on this condition for each bit.

    result(0) <= (xnum(0) AND (NOT ynum(0))) OR (xnum(1) AND (NOT ynum(1))) OR (xnum(2) AND (NOT ynum(2))) OR (xnum(3) AND (NOT ynum(3)));
    result(1) <= '0';
    result(2) <= '0';
    result(3) <= '0';
    
end hardware;

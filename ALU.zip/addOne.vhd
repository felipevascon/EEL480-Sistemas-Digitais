library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Entity declaration (addOne)
entity addOne is
    port(
        xnum: in std_logic_vector(3 downto 0); -- 4-bit input (number x)
        cout: out std_logic; -- Carry out (indicates if there was a carry in the operation)
        zeroFlag: out std_logic; -- Zero flag (indicates if the result is zero)
        signFlag: out std_logic; -- Sign flag (indicates if the result is negative)
        ovFlag: out std_logic; -- Overflow flag (indicates if there was an overflow in the operation)
        result: out std_logic_vector(3 downto 0) -- 4-bit result of the operation
    );
end addOne;

-- Architecture that describes the adder implementation
architecture hardware of addOne is

    -- Instantiation of the fourBitAdder component, which performs the 4-bit addition
    component fourBitAdder is
        port( 
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            cin : in std_logic; -- Carry in (carry input)
            cout: out std_logic; -- Carry out (carry output)
            zeroFlag: out std_logic; -- Zero flag (result == 0?)
            signFlag: out std_logic; -- Sign flag (indicates if the result is negative)
            ovFlag: out std_logic; -- Overflow flag
            result: out std_logic_vector(3 downto 0) -- Sum result (4 bits)
        );
    end component;

    -- Internal signal to represent a 4-bit vector with zero value
    signal zeroVector: std_logic_vector(3 downto 0) := (others => '0'); -- Initializes all bits as '0'

begin

    -- Instantiation of the 4-bit adder (fourBitAdder)
    -- The adder will add the input xnum with the zeroVector (value 0) and the carry-in is 1,
    -- which results in an increment of 1 to the value of xnum.
    label_1: fourBitAdder 
        port map(
            xnum,             -- The 4-bit input (xnum) will be added
            zeroVector,       -- The 4-bit zero vector (zeroVector) is added to xnum
            '1',              -- Carry in is 1 to add 1 to xnum
            cout,             -- Carry out of the operation (if there is a carry)
            zeroFlag,         -- Zero flag (will be 1 if the result is zero)
            signFlag,         -- Sign flag (will be 1 if the result is negative)
            ovFlag,           -- Overflow flag (will be 1 if overflow occurs)
            result            -- Sum result (xnum + 1)
        );

end hardware;

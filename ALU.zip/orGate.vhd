library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- 'orGate' entity performs a bitwise OR logical operation between two 4-bit vectors,
-- and generates two flags (zeroFlag and signFlag) as well as the result of the operation.
entity orGate is
    port(
        xnum: in std_logic_vector(3 downto 0);      -- First 4-bit operand
        ynum: in std_logic_vector(3 downto 0);      -- Second 4-bit operand
        zeroFlag: out std_logic;                    -- Flag indicating if the result is zero
        signFlag: out std_logic;                    -- Flag indicating the value of the most significant bit
        result: out std_logic_vector(3 downto 0)    -- Result of the bitwise OR operation
    );
end orGate;

-- Behavioral architecture of the circuit
architecture Behavioral of orGate is

    -- Internal signal that stores the result of the OR operation between xnum and ynum
    signal xnumORynum: std_logic_vector(3 downto 0);

begin

    -- Bitwise OR logical operation between the operands
    xnumORynum <= xnum OR ynum;

    -- zeroFlag will be '1' only if all the bits of the result are '0'
    -- meaning that the result of the operation was zero
    zeroFlag <= NOT(xnumORynum(0) OR xnumORynum(1) OR xnumORynum(2) OR xnumORynum(3));

    -- signFlag gets the value of the most significant bit of the result (bit 3)
    -- useful for indicating the sign in two's complement operations
    signFlag <= xnumORynum(3);

    -- Final result of the OR operation is assigned to the output
    result <= xnumORynum;

end Behavioral;

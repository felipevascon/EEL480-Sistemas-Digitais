library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

------------------------
-- Entity declaration --
------------------------
entity alu is
    port(
        sel: in std_logic_vector(3 downto 0); -- Operation selection for the ALU
        xnum: in std_logic_vector(3 downto 0); -- 4-bit input number x
        ynum: in std_logic_vector(3 downto 0); -- 4-bit input number y
        cout: out std_logic; -- Carry out of the operation (usually used for addition)
        zeroFlag: out std_logic; -- Flag indicating if the result is zero
        signFlag: out std_logic; -- Flag indicating the sign of the result (positive or negative)
        ovFlag: out std_logic; -- Overflow flag (indicates if there was overflow in the operation)
        result: out std_logic_vector(3 downto 0) -- 4-bit result of the operation
    );
end alu;

architecture hardware of alu is

    -----------------------------------------------------
    -- Instantiation of the internal ALU blocks --
    -----------------------------------------------------

    -------------------------------------------------
    -- AND Block --
    -------------------------------------------------
    component andGate is 
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            zeroFlag: out std_logic; -- Zero flag (result == 0?)
            signFlag: out std_logic; -- Sign flag
            result: out std_logic_vector(3 downto 0) -- AND operation result
        );
    end component;

    -------------------------------------------------
    -- Adder Block --
    -------------------------------------------------
    component fourBitAdder is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            cin: in std_logic; -- Carry in (carry input)
            cout: out std_logic; -- Carry out (carry output)
            zeroFlag: out std_logic; -- Zero flag
            signFlag: out std_logic; -- Sign flag
            ovFlag: out std_logic; -- Overflow flag
            result: out std_logic_vector(3 downto 0) -- Addition result
        );
    end component;

    -------------------------------------------------
    -- OR Block --
    -------------------------------------------------
    component orGate is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            zeroFlag: out std_logic; -- Zero flag
            signFlag: out std_logic; -- Sign flag
            result: out std_logic_vector(3 downto 0) -- OR operation result
        );
    end component;

    -------------------------------------------------
    -- XOR Block --
    -------------------------------------------------
    component xorGate is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            zeroFlag: out std_logic; -- Zero flag
            signFlag: out std_logic; -- Sign flag
            result: out std_logic_vector(3 downto 0) -- XOR operation result
        );
    end component;

    -------------------------------------------------
    -- Subtractor Block --
    -------------------------------------------------
    component fourBitSubtractor is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            borrowFlag: out std_logic; -- Borrow flag (for subtraction with borrow)
            zeroFlag: out std_logic; -- Zero flag
            signFlag: out std_logic; -- Sign flag
            result: out std_logic_vector(3 downto 0) -- Subtraction result
        );
    end component;

    -------------------------------------------------
    -- Comparator Block --
    -------------------------------------------------
    component equalcomp is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            result: out std_logic_vector(3 downto 0) -- Comparison result (equal)
        );
    end component;

    component lessthancomp is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            result: out std_logic_vector(3 downto 0) -- Comparison result (less than)
        );
    end component;

    component morethancomp is
        port(
            xnum: in std_logic_vector(3 downto 0); -- Input x (4 bits)
            ynum: in std_logic_vector(3 downto 0); -- Input y (4 bits)
            result: out std_logic_vector(3 downto 0) -- Comparison result (greater than)
        );
    end component;

    ------------------------------------------------------
    -- Internal signals used by the blocks --
    ------------------------------------------------------

    ------------------------------
    -- Internal signals for AND --
    ------------------------------
    signal andZeroFlag: std_logic;
    signal andSignFlag: std_logic;
    signal andResult: std_logic_vector(3 downto 0);

    ------------------------------------
    -- Internal signals for the adder --
    ------------------------------------
    signal adderCout: std_logic;
    signal adderZeroFlag: std_logic;
    signal adderSignFlag: std_logic; 
    signal adderOvFlag: std_logic;
    signal adderResult: std_logic_vector(3 downto 0);

    -----------------------------
    -- Internal signals for OR --
    -----------------------------
    signal orZeroFlag: std_logic; 
    signal orSignFlag: std_logic;
    signal orResult: std_logic_vector(3 downto 0);

    ------------------------------
    -- Internal signals for XOR --
    ------------------------------
    signal xorZeroFlag: std_logic;
    signal xorSignFlag: std_logic;
    signal xorResult: std_logic_vector(3 downto 0);

    -----------------------------------------
    -- Internal signals for the subtractor --
    -----------------------------------------
    signal subBorrow: std_logic; 
    signal subZeroFlag: std_logic; 
    signal subSignFlag: std_logic;
    signal subOvFlag: std_logic;
    signal subResult: std_logic_vector(3 downto 0);

    -----------------------------------------
    -- Internal signals for the comparator --
    -----------------------------------------
    signal equalcompResult: std_logic_vector(3 downto 0);
    signal lessthancompResult: std_logic_vector(3 downto 0);
    signal morethancompResult: std_logic_vector(3 downto 0);

begin

    ---------------------------------------------------
    -- Labels for identifying the internal blocks --
    ---------------------------------------------------
    andLabel: andGate port map(xnum, ynum, andZeroFlag, andSignFlag, andResult);
    adderLabel: fourBitAdder port map(xnum, ynum, '0', adderCout, adderZeroFlag, adderSignFlag, adderOvFlag, adderResult);
    orLabel: orGate port map(xnum, ynum, orZeroFlag, orSignFlag, orResult);
    xorLabel: xorGate port map(xnum, ynum, xorZeroFlag, xorSignFlag, xorResult);
    subtractorLabel: fourBitSubtractor port map(xnum, ynum, subBorrow, subZeroFlag, subSignFlag, subResult);
    equalcompLabel: equalcomp port map(xnum, ynum, equalcompResult);
    lessthancompLabel: lessthancomp port map(xnum, ynum, lessthancompResult);
    morethancompLabel: morethancomp port map(xnum, ynum, morethancompResult);

    ------------------------------------------------------------------------
    -- Process that selects which operation will be connected to the ALU output --
    ------------------------------------------------------------------------
    process(sel, andResult, adderResult, subResult, orResult, xorResult, equalcompResult, lessthancompResult, morethancompResult)
    begin
        -- Depending on the value of 'sel', select the corresponding ALU operation
        case sel is
            when "0000" => -- AND
                cout <= '0';
                zeroFlag <= andZeroFlag;
                signFlag <= andSignFlag;
                ovFlag <= '0';
                result <= andResult;
            when "0001" => -- ADDER
                cout <= adderCout;
                zeroFlag <= adderZeroFlag;
                signFlag <= adderSignFlag;
                ovFlag <= adderOvFlag;
                result <= adderResult;
            when "0010" => -- OR
                cout <= '0';
                zeroFlag <= orZeroFlag;
                signFlag <= orSignFlag;
                ovFlag <= '0';
                result <= orResult;
            when "0011" => -- XOR
                cout <= '0';
                zeroFlag <= xorZeroFlag;
                signFlag <= xorSignFlag;
                ovFlag <= '0';
                result <= xorResult;
            when "0100" => -- SUBTRACTOR
                cout <= subBorrow;
                zeroFlag <= subZeroFlag;
                signFlag <= subSignFlag;
                ovFlag <= subOvFlag;
                result <= subResult;
            when "0101" => -- X=Y
                cout <= '0';
                zeroFlag <= '0';
                signFlag <= '0';
                ovFlag <= '0';
                result <= equalcompResult;
            when "0110" => -- X<Y
                cout <= '0';
                zeroFlag <= '0';
                signFlag <= '0';
                ovFlag <= '0';
                result <= lessthancompResult;
            when "0111" => -- X>Y
                cout <= '0';
                zeroFlag <= '0';
                signFlag <= '0';
                ovFlag <= '0';
                result <= morethancompResult;
            when others => 
                null; -- If none of the values are valid, no operation is performed
        end case;
    end process;
end hardware;

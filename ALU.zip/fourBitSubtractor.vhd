library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declaration of the 'fourBitSubtractor' entity
-- This component performs the subtraction of two 4-bit numbers: xnum - ynum
-- using two's complement to convert the subtraction into an addition.
entity fourBitSubtractor is
    port(
        xnum: in std_logic_vector(3 downto 0);         -- Minuend (the value from which the subtraction is done)
        ynum: in std_logic_vector(3 downto 0);         -- Subtrahend (the value to be subtracted)
        borrowFlag: out std_logic;                     -- Flag indicating if there was a "borrow"
        zeroFlag: out std_logic;                       -- Flag indicating if the result is zero
        signFlag: out std_logic;                       -- Flag indicating the sign of the result
        result: out std_logic_vector(3 downto 0)       -- Result of the subtraction
    );
end fourBitSubtractor;

architecture hardware of fourBitSubtractor is

    -- Instantiation of the component that generates the two's complement of the subtrahend (ynum)
    component twosComplementer is
        port(
            xnum: in std_logic_vector(3 downto 0);     -- Input to be complemented
            zeroFlag: out std_logic;                   -- Zero flag for the complement (not used here)
            signFlag: out std_logic;                   -- Sign flag for the complement (not used here)
            result: out std_logic_vector(3 downto 0)   -- Output with the two's complement
        );
    end component;

    -- Instantiation of the 4-bit adder component to perform xnum + (-ynum)
    component fourBitAdder is
        port(
            xnum: in std_logic_vector(3 downto 0);     -- First operand
            ynum: in std_logic_vector(3 downto 0);     -- Second operand (already in two's complement)
            cin: in std_logic;                         -- Carry in (used as 0 here)
            cout: out std_logic;                       -- Carry out (interpreted as borrow)
            zeroFlag: out std_logic;                   -- Flag indicating if the result is zero
            signFlag: out std_logic;                   -- Flag indicating the sign of the result
            ovFlag: out std_logic;                     -- Overflow flag (not used here)
            result: out std_logic_vector(3 downto 0)   -- Sum result (subtraction)
        );
    end component;
    
    -- Internal signals to connect the components
    signal borrow: std_logic;                          -- Signal to capture the carry from the adder (interpreted as borrow)
    signal zeroFlagComp: std_logic;                    -- Flags from the complement (not used here)
    signal signFlagComp: std_logic;
    signal borrowFlagComp: std_logic;
    signal complemented: std_logic_vector(3 downto 0); -- Stores the two's complement of ynum
    signal ovFlag: std_logic;                          -- Overflow flag (not used)

begin

    -- First, we get the two's complement of the ynum value (subtrahend)
    complementLabel: twosComplementer 
        port map(ynum, zeroFlagComp, signFlagComp, complemented);

    -- Then, we add xnum with the two's complement of ynum (i.e., perform the subtraction)
    subtractLabel: fourBitAdder 
        port map(xnum, complemented, '0', borrow, zeroFlag, signFlag, ovFlag, result);

    -- The borrowFlag output receives the value of the carry out from the adder, indicating if there was a "borrow"
    borrowFlag <= borrow;

end hardware;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declaration of the xorGate entity
entity xorGate is
    port(
        xnum: in std_logic_vector(3 downto 0); -- 4-bit input (xnum)
        ynum: in std_logic_vector(3 downto 0); -- 4-bit input (ynum)
        zeroFlag: out std_logic; -- Flag indicating if the result is zero
        signFlag: out std_logic; -- Flag indicating the sign (most significant bit)
        result: out std_logic_vector(3 downto 0) -- Result of the XOR operation
    );
end xorGate;

-- Architecture that describes the operation of the XOR gate
architecture hardware of xorGate is

    -- Internal signal to store the result of the XOR operation between xnum and ynum
    signal xnumXORynum: std_logic_vector(3 downto 0);

begin

    -- Bitwise XOR operation between xnum and ynum
    -- The XOR operation returns '1' when the compared bits are different, and '0' when they are the same
    xnumXORynum <= xnum XOR ynum;

    -- The zeroFlag will be '1' if all bits of the XOR result are '0' (indicating that the result is zero)
    zeroFlag <= NOT( xnumXORynum(0) OR xnumXORynum(1) OR xnumXORynum(2) OR xnumXORynum(3));

    -- The signFlag is the most significant bit of the result (bit 3), indicating the sign of the number (in two's complement systems)
    signFlag <= xnumXORynum(3);

    -- The result of the XOR operation is assigned to the result vector
    result <= xnumXORynum;

end hardware;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Declaration of the 'fullAdder' entity
-- This entity implements a 1-bit full adder,
-- which adds two input bits (xnum and ynum) and a carry-in bit (cin),
-- generating a result (result) and a carry-out (cout).
entity fullAdder is
    port(
        xnum: in std_logic;       -- First operand (single bit)
        ynum: in std_logic;       -- Second operand (single bit)
        cin: in std_logic;        -- Carry-in bit
        cout: out std_logic;      -- Carry-out bit
        result: out std_logic     -- Sum result (single bit)
    );
end fullAdder;

-- Architecture of the full adder
architecture hardware of fullAdder is
begin

    -- Addition operation:
    -- Bitwise addition considering the carry-in (cin)
    -- (xnum XOR ynum) performs the addition of the bits without carry
    -- The second XOR with cin adds the carry to the sum
    result <= (xnum XOR ynum) XOR cin;

    -- Calculation of carry-out (cout):
    -- There is a carry-out if at least two of the three inputs are '1'
    -- This expression represents all possible combinations that generate a carry
    cout <= ((xnum AND ynum) OR (xnum AND cin)) OR (ynum AND cin);

end hardware;
